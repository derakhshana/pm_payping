<?php
/**
 * @version      1.00
 * @author       Ali Derakhshan
 * @package      pm_payping
 * @copyright    Copyright (C) 2020
 * @license      GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');

?>

<script type="text/javascript">
function check_pm_payping(){
    $_('payment_form').submit();
}
</script>
<a target="_blank" title="Payping trust payment">
<img src="https://cdn.payping.ir/statics/Payping-logo/Trust/blue.svg" alt="Payping trust peyment" style="width:64px;height:77px;">
</a>